using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using LicensingProject.Models;
using LicensingProject.Models.Repositories;

namespace LicensingProject.Controllers
{
    public class RequestController : Controller
    {
        private readonly ILicensingRepository<Request> requestRepository;
        private readonly IHostingEnvironment hosting;

        public RequestController(ILicensingRepository<Request> requestRepository,
            IHostingEnvironment hosting)
        {
            this.requestRepository = requestRepository;
            this.hosting = hosting;
        }

        // GET: request
        public IActionResult Index()
        {
            var requests = requestRepository.List();
            return View(requests);
        }


    }
}

