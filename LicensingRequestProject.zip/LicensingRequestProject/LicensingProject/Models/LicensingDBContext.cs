﻿using System;
using Microsoft.EntityFrameworkCore;
namespace LicensingProject.Models
{
    public class LicensingDBContext:DbContext
    {
        public LicensingDBContext(DbContextOptions<LicensingDBContext> options):base(options)
        {
            
        }

        //public DbSet<Requester> Requesters { get; set; }
        public DbSet<Request> Requests { get; set; }
    }
}
