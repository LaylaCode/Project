﻿using System;
using System.Collections.Generic;

namespace LicensingProject.Models.Repositories
{
        public interface ILicensingRepository<TEntity>
        {

            IList<TEntity> List();
        }
    }

