﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace LicensingProject.Models.Repositories
{
    public class RequestRepository : ILicensingRepository<Request>
    {

       List<Request> requests;

       public RequestRepository()
       {

            requests = new List<Request>()
            {


                new Request
                 {
                    FullName="السيد الشاذلي", RequestType="طلب ترخيص جديد", Id = 4, RequestStatus = " يعاد إلى مقدم الطلب لإكمال الأوراق أو توضيحها"
                    
                 },
                new Request
                 {
                    FullName="إياد الحسن", RequestType="طلب إعادة قيد", Id=5,  RequestStatus = " في انتظار نتيجة المسح الأمني "
                    
                 },
                new Request
                 {
                    FullName="سعد الدخيل",  RequestType="طلب إعادة قيد", Id = 6 , RequestStatus = " موافقة نظام التراخيص"
                    
                 },
                new Request
                 {
                    FullName="سعود العتيبي",  RequestType="طلب إعادة قيد", Id=9 , RequestStatus=" موافقة نظام التراخيص"
                    
                 },
                new Request
                 {
                    FullName="عيسى عبده",  RequestType="طلب ترخيص جديد", Id=10, RequestStatus=" في انتظار نتيجة المسح الأمني"
                    
                 },
                new Request
                 {
                    FullName="عبدالرحمن صالح الغامدي",  RequestType="طلب إعادة قيد", Id=11 , RequestStatus=" تمت الموافقة"
                    
                 },
                new Request
                 {
                    FullName="محمد أحمد", RequestType="طلب إعادة قيد", Id=12 , RequestStatus=" في انتظار نتيجة المسح الأمني"
                    
                 },
                new Request
                 {
                    FullName="أحمد سالم",  RequestType="طلب ترخيص جديد", Id=13 , RequestStatus=" في انتظار نتيجة المسح الأمني"
                    
                 },
                new Request
                 {
                    FullName="عامر محمد أحمد",  RequestType="طلب ترخيص جديد", Id=14 , RequestStatus=" تمت الموافقة"
                    
                 },
                new Request
                 {
                    FullName="حمود النفيعي" , RequestType="طلب إعادة قيد", Id=15 , RequestStatus=" موافقة نظام التراخيص"
                    
                 }
            };

       }

        public IList<Request> List()
        {
            return requests;
        }

    }
}
    



