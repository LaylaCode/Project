﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace LicensingProject.Models
{
    public class Request
    {
        //public Requester Requester { get; set; }
        public string FullName { get; set; }
        public string RequestType { get; set; }
        public int Id { get; set; }
        //public int RequestNumber { get; set; }
        public string RequestStatus { get; set; }
        

    }
}




