﻿using System;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LicensingProject.Views.Request
{
    public class IndexModel : PageModel
    {
       public void OnGet()
            {
            }
        }
    }

